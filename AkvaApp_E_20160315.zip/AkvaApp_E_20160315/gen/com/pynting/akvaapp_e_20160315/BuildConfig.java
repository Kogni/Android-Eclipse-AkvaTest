/** Automatically generated file. DO NOT MODIFY */
package com.pynting.akvaapp_e_20160315;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}